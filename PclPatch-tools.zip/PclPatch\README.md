# PclPatch —— 补丁工具

把官方 PCL 2.99.0.0 的 `pcl.exe` 变成恢复 MC 下载功能的版本。

## 环境

- .NET SDK 8/9（`dotnet --version` 能输出即可）
- 首次运行需要联网还原 NuGet 包（dnlib 4.4.0）

## 用法

```bash
# 1. 先看看目标 exe 的开关分布（可选）
dotnet run -c Release -- scan "C:\path\to\official\pcl.exe"

# 2. 生成补丁版
dotnet run -c Release -- fix "C:\path\to\official\pcl.exe" "C:\path\to\output\pcl.exe"
```

`scan` 预期输出（2.99.0.0）：

```
PCL.ModModpack::ModpackInstall [2] 限制提示语
PCL.ModModpack::ModpackInstall [246] 限制提示语
```

## 做了什么

只重写 `PCL.PageDownloadInstall::LoaderInit` 的方法体，等价于源码：

```vb
Public Overridable Sub LoaderInit() Handles Me.Initialized
    ControlInit()
    PageLoaderInit(LoadMinecraft, PanLoad, PanAllBack, Nothing,
                   DlClientListLoader, AddressOf LoadMinecraft_OnFinish)
End Sub
```

- `DlClientListLoader` 是 `PCL.ModDownload` 里现成的版本清单加载器；
- `LoadMinecraft_OnFinish` 在官方 exe 里存在（无参版本），由编译器生成的
  `_Lambda$__R3-4(LoaderTask<...>)` 适配成 `Action` 委托——直接复用，避免手写回调。

## 为什么不用源码重编

官方在编译期把 `If RestrictMcDownload Then` 的 else 分支整体删掉了，
用开源仓库重编会丢掉官方专属代码（微软登录 Client ID、联机配置等）。
二进制补丁只动一个方法，官方功能完整保留。

## 注意

- 只适配 2.99.0.0；其它版本方法体指令序列不同，`fix` 会取错操作数或抛异常；
- 输出未签名，SmartScreen 会提示未知发布者；
- PCL 自动更新后会被官方 exe 覆盖。

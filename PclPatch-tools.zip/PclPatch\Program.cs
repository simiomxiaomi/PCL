using dnlib.DotNet;
using dnlib.DotNet.Emit;
using dnlib.DotNet.Writer;

// PCL (Minecraft Download Fix) —— 官方 PCL 2.99.0.0 的 MC 下载功能补丁工具
//
// 用法：
//   PclPatch scan <pcl.exe>                 列出与 RestrictMcDownload 相关的常量使用点
//   PclPatch fix  <官方 pcl.exe> <输出.exe>  生成恢复 MC 下载功能的 exe
//
// 原理：官方在编译期把 `If RestrictMcDownload Then` 的 else 分支删掉了，
// PageDownloadInstall::LoaderInit 只剩“关闭下载”一个加载器。这里把该方法体替换为
// 调用程序内部已有的 DlClientListLoader，并使用 exe 内现成的 _Lambda$__R3-4 作为回调
// （它内部调用 LoadMinecraft_OnFinish，负责把版本列表灌进页面）。
// 只改这一个方法，其余 IL、资源、元数据原样保留（dnlib 会保留 Win32 资源，
// 因此图标、manifest、版本信息都不会丢）。

if (args.Length < 2)
{
    Console.Error.WriteLine("usage:");
    Console.Error.WriteLine("  PclPatch scan <pcl.exe>");
    Console.Error.WriteLine("  PclPatch fix  <official pcl.exe> <out.exe>");
    return 1;
}

var mode = args[0];
var input = args[1];
var mod = ModuleDefMD.Load(input);

if (mode == "scan")
{
    foreach (var name in new[] { "PCL.PageDownloadInstall", "PCL.PageDownloadModify", "PCL.PageDownloadResourceDetail", "PCL.ModModpack" })
    {
        var t = mod.Find(name, false);
        if (t == null) { Console.WriteLine($"missing type {name}"); continue; }
        foreach (var m in t.Methods)
        {
            if (!m.HasBody) continue;
            var ins = m.Body.Instructions;
            for (int i = 0; i < ins.Count; i++)
            {
                if (ins[i].OpCode == OpCodes.Ldstr && ins[i].Operand is string s && s.Contains("暂时不再提供"))
                    Console.WriteLine($"{name}::{m.Name} [{i}] 限制提示语");
                if (ins[i].OpCode == OpCodes.Ldc_I4_1 && i + 1 < ins.Count &&
                    (ins[i + 1].OpCode == OpCodes.Call || ins[i + 1].OpCode == OpCodes.Callvirt) &&
                    ins[i + 1].Operand?.ToString().Contains("set_Visibility") == true)
                    Console.WriteLine($"{name}::{m.Name} [{i}] ldc.i4.1 -> set_Visibility");
            }
        }
    }
    return 0;
}

if (mode == "fix")
{
    if (args.Length < 3) { Console.Error.WriteLine("fix 需要输出路径"); return 1; }
    var outPath = args[2];

    var pageType = mod.Find("PCL.PageDownloadInstall", false)
        ?? throw new Exception("找不到类型 PCL.PageDownloadInstall，目标 exe 可能不是 2.99.0.0");
    var loaderInit = pageType.FindMethod("LoaderInit")
        ?? throw new Exception("找不到方法 PageDownloadInstall::LoaderInit");
    var old = loaderInit.Body.Instructions;

    // 复用原方法里已有的元数据引用，避免引入新的成员引用
    object controlInit = old[1].Operand;        // ControlInit()
    object getLoadMinecraft = old[4].Operand;   // get_LoadMinecraft
    object getPanLoad = old[6].Operand;         // get_PanLoad
    object getPanAllBack = old[8].Operand;      // get_PanAllBack
    object actionCtor = old[25].Operand;        // Action<LoaderTask<string, DlClientListResult>>::.ctor
    object pageLoaderInit = old[28].Operand;    // MyPageRight::PageLoaderInit<string, DlClientListResult>

    var loaderField = mod.Find("PCL.ModDownload", false)?.FindField("DlClientListLoader")
        ?? throw new Exception("找不到字段 ModDownload::DlClientListLoader");
    object onFinish = old[24].Operand;          // _Lambda$__R3-4(LoaderTask<...>)

    var body = new CilBody { InitLocals = false };
    var il = body.Instructions;
    il.Add(Instruction.Create(OpCodes.Ldarg_0));
    il.Add(Instr(OpCodes.Call, controlInit));
    il.Add(Instruction.Create(OpCodes.Ldarg_0));            // this（PageLoaderInit 的调用目标）
    il.Add(Instruction.Create(OpCodes.Ldarg_0));
    il.Add(Instr(OpCodes.Callvirt, getLoadMinecraft));      // LoaderUi
    il.Add(Instruction.Create(OpCodes.Ldarg_0));
    il.Add(Instr(OpCodes.Callvirt, getPanLoad));            // PanLoader
    il.Add(Instruction.Create(OpCodes.Ldarg_0));
    il.Add(Instr(OpCodes.Callvirt, getPanAllBack));         // PanContent
    il.Add(Instruction.Create(OpCodes.Ldnull));             // PanAlways = Nothing
    il.Add(Instruction.Create(OpCodes.Ldsfld, loaderField));// Loader = DlClientListLoader
    il.Add(Instruction.Create(OpCodes.Ldarg_0));
    il.Add(Instr(OpCodes.Ldftn, onFinish));
    il.Add(Instr(OpCodes.Newobj, actionCtor));              // OnFinish 委托
    il.Add(Instruction.Create(OpCodes.Ldnull));             // InputDelegate = Nothing
    il.Add(Instruction.Create(OpCodes.Ldc_I4_1));           // ShowLoader = True
    il.Add(Instr(OpCodes.Call, pageLoaderInit));
    il.Add(Instruction.Create(OpCodes.Ret));

    loaderInit.Body = body;
    Console.WriteLine("patched: PCL.PageDownloadInstall::LoaderInit");
    Console.WriteLine("  loader  : " + loaderField.FullName);
    Console.WriteLine("  onFinish: " + (onFinish as IMethodDefOrRef)?.FullName);

    mod.Write(outPath, new ModuleWriterOptions(mod));
    Console.WriteLine("written : " + outPath);
    return 0;
}

Console.Error.WriteLine("unknown mode: " + mode);
return 1;

static Instruction Instr(OpCode op, object operand) => operand switch
{
    MethodSpec ms => Instruction.Create(op, ms),
    IMethodDefOrRef md => Instruction.Create(op, md),
    IField fd => Instruction.Create(op, fd),
    _ => throw new NotSupportedException(operand?.GetType().FullName ?? "null")
};
